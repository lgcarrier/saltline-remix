CS 1.6 cs_italy — overview, stock map, and OBJ export
=====================================================

Contents
--------
cs_italy.bmp    Official GoldSrc spectator overview (cstrike/overviews/cs_italy.bmp)
cs_italy.bsp    Stock GoldSrc BSP version 30
cs_italy.obj    Worldspawn (model 0) geometry
cs_italy.mtl    One material per GoldSrc texture name
textures/       PNG textures extracted from the WAD files listed below
README.txt      This file

Sources (verified live)
-----------------------
Overview BMP, MD5 835e14480ae7233aae6df3025fc3d317, 1024x768 8-bit,
identical on:
  https://gamekill.cz/cstrike/overviews/cs_italy.bmp
  https://www.geforce.nl/~mb/files/cstrike/overviews/cs_italy.bmp
  Directory: https://gamekill.cz/cstrike/overviews/

Map BSP, MD5 75998195a8993406197ded3fc7e3f651, version 30, 2,303,480 bytes,
identical on:
  https://gamekill.cz/cstrike/maps/cs_italy.bsp
  https://www.geforce.nl/~mb/files/cstrike/maps/cs_italy.bsp

Worldspawn "wad" key in the BSP:
  \sierra\half-life\cstrike\cstrike.wad;
  \sierra\half-life\valve\halflife.wad;
  \sierra\half-life\cstrike\decals.wad;
  \pics\itsitaly.wad

There is no cs_italy.wad on these mirrors (both returned 404).
No miptex were embedded in the BSP.

Textures used by the OBJ were extracted from:
  https://www.geforce.nl/~mb/files/cstrike/itsitaly.wad
    (MD5 430dc9cbfafaf66e06d96ac772c91e6d, identical to
     https://gamekill.cz/cstrike/itsitaly.wad)
    75 of the 80 used materials
  https://www.geforce.nl/~mb/files/cstrike/halflife.wad
    5 of the 80 used materials
    (no second live mirror for this WAD was found)

cstrike.wad and decals.wad are listed in the wad key but were not
needed for any model 0 material.

Coordinate system and scale
---------------------------
The OBJ keeps native GoldSrc / Quake coordinates:
  X right, Y forward (north), Z up
  1 unit is about 1 inch
  To get meters, scale by 0.0254

The official overview image is rotated 90 degrees counter-clockwise
relative to a simple top-down X/Y plot. The OBJ itself is not rotated.

Blender import
--------------
File > Import > Wavefront (.obj)
  - Up axis: Z
  - Forward axis: Y
  - Scale: 0.0254 (optional; leave at 1.0 to stay in inches)
  - Enable material/image import so textures/ next to the MTL is found

UVs: V was flipped (1 - t/height) so textures are right-side-up in
OpenGL/Blender. If a texture looks upside-down, scale UV V by -1.

Export notes
------------
- Only model 0 (worldspawn) faces are included. Brush entities such as
  func_door or func_wall are not in this mesh.
- Faces textured with sky, aaatrigger, clip, origin, {invisible, or
  other null-ish tool textures were skipped. On this map, model 0 only
  needed to skip "sky".
- 10,100 vertices, 17,157 UVs, 7,176 faces (about 19,582 triangles),
  80 materials. All 80 used textures were extracted to PNG.
  None were missing.
- Bounding box (native units):
    min (-1664, -2560, -240)
    max ( 1168,  2592,  512)
- Streets, interiors, and rooftops sit at different heights, so a
  top-down view overlaps some floors; that is expected.

License / use
-------------
These maps, overviews, and textures are Valve / Counter-Strike assets.
This zip is for personal use (viewing, study, or importing the layout).
Do not redistribute them as your own work or use them commercially.
