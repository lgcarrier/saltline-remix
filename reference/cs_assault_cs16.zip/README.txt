CS 1.6 cs_assault — overview, stock map, and OBJ export
=======================================================

Contents
--------
cs_assault.bmp   Official GoldSrc spectator overview (cstrike/overviews/cs_assault.bmp)
cs_assault.bsp   Stock GoldSrc BSP version 30
cs_assault.obj   Worldspawn (model 0) geometry
cs_assault.mtl   One material per GoldSrc texture name
textures/        PNG textures extracted from the WAD files listed below
README.txt       This file

Sources (verified live)
-----------------------
Overview BMP, MD5 8a7810da76a71eed547e3790d6f51300, identical on:
  https://gamekill.cz/cstrike/overviews/cs_assault.bmp
  https://www.geforce.nl/~mb/files/cstrike/overviews/cs_assault.bmp
  Directory: https://gamekill.cz/cstrike/overviews/

Map BSP, MD5 dbe0e8c5101a663412a3258d7f90d6c2, version 30, 1,041,700 bytes,
identical on:
  https://gamekill.cz/cstrike/maps/cs_assault.bsp
  https://www.geforce.nl/~mb/files/cstrike/maps/cs_assault.bsp

Worldspawn "wad" key in the BSP:
  \halflife\valve\decals.wad;
  \halflife\valve\halflife.wad;
  \halflife\cstrike\cs_assault.wad;

Textures used by the OBJ were extracted from:
  https://gamekill.cz/cstrike/cs_assault.wad
    (MD5 f6dbce04381125ab485ce5e5fcf9b8e1, identical to
     https://www.geforce.nl/~mb/files/cstrike/cs_assault.wad)
    18 of the 103 used materials
  https://www.geforce.nl/~mb/files/cstrike/halflife.wad
    85 of the 103 used materials
    (no second live mirror for this WAD was found; gamekill /cstrike/halflife.wad 404)

decals.wad is listed in the wad key but was not needed for any model 0
material. No miptex were embedded in the BSP (all offsets were 0).

Coordinate system and scale
---------------------------
The OBJ keeps native GoldSrc / Quake coordinates:
  X right, Y forward (north), Z up
  1 unit is about 1 inch
  To get meters, scale by 0.0254

The official overview image is rotated 90 degrees counter-clockwise
relative to a simple top-down X/Y plot. The OBJ itself is not rotated.

Blender import
--------------
File > Import > Wavefront (.obj)
  - Up axis: Z
  - Forward axis: Y
  - Scale: 0.0254 (optional; leave at 1.0 to stay in inches)
  - Enable material/image import so textures/ next to the MTL is found

UVs: V was flipped (1 - t/height) so textures are right-side-up in
OpenGL/Blender. If a texture looks upside-down, scale UV V by -1.

Export notes
------------
- Only model 0 (worldspawn) faces are included. Brush entities such as
  func_door, func_ladder, or func_wall are not in this mesh. Fence and
  ladder textures exist in the BSP texture list but were not used on
  model 0.
- Faces textured with sky, aaatrigger, clip, origin, {invisible, or
  other null-ish tool textures were skipped. On this map, model 0 only
  needed to skip "sky".
- 2,805 vertices, 4,601 UVs, 2,087 faces (about 5,547 triangles),
  103 materials. All 103 used textures were extracted to PNG.
  None were missing.
- Bounding box (native units):
    min (-2688, -1088, 0)
    max ( 1216,  3136, 768)
- This map is multi-level (warehouse interior, roof, highway). A
  top-down view overlaps floors; that is expected and is not a
  missing-geometry error.

License / use
-------------
These maps, overviews, and textures are Valve / Counter-Strike assets.
This zip is for personal use (viewing, study, or importing the layout).
Do not redistribute them as your own work or use them commercially.
