CS 1.6 de_dust — overview, stock map, and OBJ export
====================================================

Contents
--------
de_dust.bmp   Official GoldSrc spectator overview (cstrike/overviews/de_dust.bmp)
de_dust.bsp   Stock GoldSrc BSP version 30
de_dust.obj   Worldspawn (model 0) geometry
de_dust.mtl   One material per GoldSrc texture name
textures/     PNG textures extracted from de_dust.wad
README.txt    This file

Sources (verified live)
-----------------------
Overview BMP, MD5 36ef29ae6f473cfaa31e84a45c1ce1f5, identical on:
  https://gamekill.cz/cstrike/overviews/de_dust.bmp
  https://www.geforce.nl/~mb/files/cstrike/overviews/de_dust.bmp
  Directory: https://gamekill.cz/cstrike/overviews/

Map BSP, MD5 211aaae4d5b468edc8250e9d453607e7, version 30, 1,359,684 bytes,
identical on:
  https://gamekill.cz/cstrike/maps/de_dust.bsp
  https://www.geforce.nl/~mb/files/cstrike/maps/de_dust.bsp

Textures used by the OBJ were extracted from:
  https://gamekill.cz/cstrike/de_dust.wad
  (the same visible sand/crate textures are also in
   https://www.geforce.nl/~mb/files/cstrike/cs_dust.wad)

Coordinate system and scale
---------------------------
The OBJ keeps native GoldSrc / Quake coordinates:
  X right, Y forward (north), Z up
  1 unit is about 1 inch
  To get meters, scale by 0.0254

The official overview image is rotated 90 degrees counter-clockwise
relative to a simple top-down X/Y plot. The OBJ itself is not rotated.

Blender import
--------------
File > Import > Wavefront (.obj)
  - Up axis: Z
  - Forward axis: Y
  - Scale: 0.0254 (optional; leave at 1.0 to stay in inches)
  - Enable material/image import so textures/ next to the MTL is found

UVs: V was flipped (1 - t/height) so textures are right-side-up in
OpenGL/Blender. If a texture looks upside-down, scale UV V by -1.

Export notes
------------
- Only model 0 (worldspawn) faces are included. Brush entities such as
  func_door or func_breakable are not in this mesh.
- Faces textured with sky, aaatrigger, clip, origin, or other null-ish
  tool textures were skipped. On this map, model 0 only needed to skip
  "sky".
- 5,644 vertices, 4,221 faces (about 10,655 triangles), 19 materials.
  All 19 used textures were extracted to PNG.
- Bounding box (native units):
    min (-2832, -2048, -192)
    max ( 2624,  3968,  416)

License / use
-------------
These maps, overviews, and textures are Valve / Counter-Strike assets.
This zip is for personal use (viewing, study, or importing the layout).
Do not redistribute them as your own work or use them commercially.
